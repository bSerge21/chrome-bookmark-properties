// ── State ──────────────────────────────────────────────────────────────────
let selectedBookmark = null;
let selectedPath     = "";
let searchTimeout    = null;

// ── Tab switching ──────────────────────────────────────────────────────────
const tabs = document.querySelectorAll(".tab");
const views = {};
tabs.forEach(tab => {
  const id = tab.dataset.tab;
  views[id] = document.getElementById(`view-${id}`);
  tab.addEventListener("click", () => switchTab(id));
});

function switchTab(id) {
  tabs.forEach(t => t.classList.toggle("active", t.dataset.tab === id));
  Object.entries(views).forEach(([k, v]) => v.classList.toggle("active", k === id));
  document.getElementById("searchBar").style.display = id === "search" ? "block" : "none";
  if (id === "stats") loadStats();
}

// ── Direct chrome.bookmarks wrappers ───────────────────────────────────────
function bmGetRecent(count) {
  return new Promise((res, rej) =>
    chrome.bookmarks.getRecent(count, r => chrome.runtime.lastError ? rej(chrome.runtime.lastError) : res(r)));
}
function bmSearch(query) {
  return new Promise((res, rej) =>
    chrome.bookmarks.search(query, r => chrome.runtime.lastError ? rej(chrome.runtime.lastError) : res(r)));
}
function bmGet(id) {
  return new Promise((res, rej) =>
    chrome.bookmarks.get(id, r => chrome.runtime.lastError ? rej(chrome.runtime.lastError) : res(r[0])));
}
function bmUpdate(id, changes) {
  return new Promise((res, rej) =>
    chrome.bookmarks.update(id, changes, r => chrome.runtime.lastError ? rej(chrome.runtime.lastError) : res(r)));
}
function bmGetTree() {
  return new Promise((res, rej) =>
    chrome.bookmarks.getTree(r => chrome.runtime.lastError ? rej(chrome.runtime.lastError) : res(r)));
}

async function getFullPath(parentId) {
  const parts = [];
  let id = parentId;
  while (id) {
    try {
      const node = await bmGet(id);
      if (node.title) parts.unshift(node.title);
      id = node.parentId;
    } catch { break; }
  }
  return parts.join(" › ");
}

// ── Recent bookmarks ────────────────────────────────────────────────────────
async function loadRecent() {
  try {
    const results = await bmGetRecent(30);
    document.getElementById("recentLoading").style.display = "none";
    renderBookmarkList(results, "recentList");
  } catch(e) {
    document.getElementById("recentLoading").innerHTML =
      `<span style="color:var(--red)">Error: ${e.message}</span>`;
  }
}

function renderBookmarkList(items, listId) {
  const list = document.getElementById(listId);
  list.innerHTML = "";
  if (!items || !items.length) {
    list.innerHTML = `<div class="empty-state"><div class="icon">📭</div><p>No bookmarks found</p></div>`;
    return;
  }
  items.filter(b => b.url).forEach(b => {
    const el = document.createElement("div");
    el.className = "bookmark-item" + (selectedBookmark?.id === b.id ? " selected" : "");
    const d = b.dateAdded ? new Date(b.dateAdded) : null;
    el.innerHTML = `
      <div class="bm-title">${escHtml(b.title || "(no title)")}</div>
      <div class="bm-url">${escHtml(b.url || "")}</div>
      ${d ? `<div class="bm-date">⏱ ${formatDate(d)}</div>` : ""}
    `;
    el.addEventListener("click", () => selectBookmark(b, el, listId));
    list.appendChild(el);
  });
}

function selectBookmark(bookmark, el, listId) {
  // Deselect previous
  document.querySelectorAll(".bookmark-item.selected").forEach(e => e.classList.remove("selected"));
  el.classList.add("selected");
  selectedBookmark = bookmark;
  loadAndShowProps(bookmark);
}

// ── Properties ──────────────────────────────────────────────────────────────
async function loadAndShowProps(bookmark) {
  switchTab("props");
  const container = document.getElementById("propsContent");
  container.innerHTML = `<div class="loading-row"><span class="spinner"></span> Loading…</div>`;

  let path = "";
  try {
    path = await getFullPath(bookmark.parentId);
    selectedPath = path;
  } catch(e) {}

  renderProps(bookmark, path);
}

function renderProps(b, path) {
  const container = document.getElementById("propsContent");
  const isFolder = !b.url;

  const dateAdded   = b.dateAdded     ? new Date(b.dateAdded)    : null;
  const dateModified = b.dateModified ? new Date(b.dateModified) : null;
  const dateLast    = b.dateLastUsed  ? new Date(b.dateLastUsed) : null;

  // Favicon URL (best effort)
  const faviconUrl = b.url
    ? `https://www.google.com/s2/favicons?domain=${encodeURIComponent(new URL(b.url).hostname)}&sz=32`
    : "";

  container.innerHTML = `
    <div class="props-container">
      <div class="props-header">
        ${b.url
          ? `<img src="${faviconUrl}" style="width:24px;height:24px;margin-bottom:8px;border-radius:4px" onerror="this.style.display='none'">`
          : `<div class="props-icon">📁</div>`}
        <div class="props-title">${escHtml(b.title || "(no title)")}</div>
        ${b.url ? `<a class="props-url" href="${escHtml(b.url)}" target="_blank">${escHtml(b.url)}</a>` : ""}
      </div>

      ${path ? `
        <div>
          <div class="section-label">Location</div>
          <div class="path-crumb"><span>${escHtml(path)}</span></div>
        </div>
      ` : ""}

      <div>
        <div class="section-label">Details</div>
        <div class="prop-grid">
          ${propRow("ID", b.id)}
          ${propRow("Type", isFolder ? "📁 Folder" : "🔖 Bookmark")}
          ${dateAdded    ? propRow("Created",  formatDateFull(dateAdded),  dateAdded.getTime())  : ""}
          ${dateModified ? propRow("Modified", formatDateFull(dateModified), dateModified.getTime()) : ""}
          ${dateLast     ? propRow("Last used", formatDateFull(dateLast),  dateLast.getTime())   : ""}
          ${b.url ? propRow("Domain", new URL(b.url).hostname) : ""}
          ${b.parentId !== undefined ? propRow("Parent ID", b.parentId) : ""}
          ${b.index !== undefined ? propRow("Position", "#" + b.index) : ""}
        </div>
      </div>

      <div>
        <div class="section-label">Edit</div>
        <div class="edit-section">
          <div class="field-group">
            <div class="field-label">Title</div>
            <input class="field-input" id="editTitle" value="${escAttr(b.title || "")}">
          </div>
          ${b.url ? `
          <div class="field-group">
            <div class="field-label">URL</div>
            <input class="field-input" id="editUrl" value="${escAttr(b.url || "")}">
          </div>
          ` : ""}
          <div class="btn-row">
            <button class="btn btn-primary" id="saveBtn">💾 Save</button>
            <button class="btn btn-ghost" id="openBtn" ${!b.url ? "disabled" : ""}>↗ Open</button>
          </div>
        </div>
      </div>

      ${b.url ? `
      <div>
        <div class="section-label">Raw URL</div>
        <div class="path-crumb" style="display:flex;align-items:flex-start;gap:8px;justify-content:space-between">
          <span style="word-break:break-all;font-size:10px;color:var(--muted)">${escHtml(b.url)}</span>
          <button class="copy-btn" id="copyUrl" style="flex-shrink:0;background:none;border:1px solid var(--border);border-radius:3px;color:var(--muted);font-size:9px;padding:2px 6px;cursor:pointer">copy</button>
        </div>
      </div>
      ` : ""}
    </div>
  `;

  // Bind save
  document.getElementById("saveBtn").addEventListener("click", async () => {
    const changes = { title: document.getElementById("editTitle").value };
    const urlInput = document.getElementById("editUrl");
    if (urlInput) changes.url = urlInput.value;
    try {
      await bmUpdate(b.id, changes);
      showToast("✓ Saved");
      Object.assign(b, changes);
    } catch(e) {
      showToast("✗ " + e.message, true);
    }
  });

  // Open in tab
  document.getElementById("openBtn")?.addEventListener("click", () => {
    if (b.url) chrome.tabs.create({ url: b.url });
  });

  // Copy URL
  document.getElementById("copyUrl")?.addEventListener("click", function() {
    navigator.clipboard.writeText(b.url).then(() => {
      this.textContent = "✓";
      this.classList.add("copied");
      setTimeout(() => { this.textContent = "copy"; this.classList.remove("copied"); }, 1500);
    });
  });

  // Copy buttons
  container.querySelectorAll(".copy-btn[data-val]").forEach(btn => {
    btn.addEventListener("click", () => {
      navigator.clipboard.writeText(btn.dataset.val).then(() => {
        const orig = btn.textContent;
        btn.textContent = "✓";
        btn.classList.add("copied");
        setTimeout(() => { btn.textContent = orig; btn.classList.remove("copied"); }, 1500);
      });
    });
  });
}

function propRow(key, val, copyVal) {
  const cv = copyVal !== undefined ? copyVal : val;
  return `
    <div class="prop-row">
      <div class="prop-key">${escHtml(key)}</div>
      <div class="prop-val">
        <span style="flex:1">${escHtml(String(val))}</span>
        <button class="copy-btn" data-val="${escAttr(String(cv))}">copy</button>
      </div>
    </div>
  `;
}

// ── Search ──────────────────────────────────────────────────────────────────
document.getElementById("searchInput").addEventListener("input", (e) => {
  clearTimeout(searchTimeout);
  const q = e.target.value.trim();
  if (!q) {
    document.getElementById("searchList").innerHTML = `<div class="empty-state"><div class="icon">🔍</div><p>Type to search bookmarks by title or URL</p></div>`;
    return;
  }
  searchTimeout = setTimeout(async () => {
    const results = await bmSearch(q);
    renderBookmarkList(results || [], "searchList");
  }, 250);
});

// ── Stats ────────────────────────────────────────────────────────────────────
async function loadStats() {
  const loading = document.getElementById("statsLoading");
  const content = document.getElementById("statsContent");
  loading.style.display = "flex";
  content.style.display  = "none";

  const tree = await bmGetTree();
  const all = flattenTree(tree);
  const bookmarks = all.filter(n => n.url);
  const folders   = all.filter(n => !n.url && n.id !== "0");

  // Oldest / newest
  const sorted = [...bookmarks].filter(b => b.dateAdded).sort((a, b) => a.dateAdded - b.dateAdded);
  const oldest = sorted.slice(0, 5);
  const newest = sorted.slice(-5).reverse();

  // Domain diversity
  const domains = new Set(bookmarks.map(b => { try { return new URL(b.url).hostname; } catch { return ""; } }));

  document.getElementById("statsGrid").innerHTML = `
    <div class="stat-card"><div class="stat-val">${bookmarks.length}</div><div class="stat-label">Bookmarks</div></div>
    <div class="stat-card"><div class="stat-val">${folders.length}</div><div class="stat-label">Folders</div></div>
    <div class="stat-card"><div class="stat-val">${domains.size}</div><div class="stat-label">Domains</div></div>
    <div class="stat-card"><div class="stat-val">${oldest[0] ? new Date(oldest[0].dateAdded).getFullYear() : "—"}</div><div class="stat-label">Oldest year</div></div>
  `;

  renderBookmarkList(oldest, "oldestList");
  renderBookmarkList(newest, "newestList");

  loading.style.display = "none";
  content.style.display  = "block";
}

function flattenTree(nodes, result = []) {
  if (!nodes) return result;
  for (const node of nodes) {
    result.push(node);
    if (node.children) flattenTree(node.children, result);
  }
  return result;
}

// ── Live updates ────────────────────────────────────────────────────────────
chrome.bookmarks.onChanged.addListener((id, changeInfo) => {
  if (selectedBookmark?.id === id) {
    Object.assign(selectedBookmark, changeInfo);
    renderProps(selectedBookmark, selectedPath);
  }
});
chrome.bookmarks.onCreated.addListener(() => {
  loadRecent();
});

// ── Helpers ─────────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function escAttr(s) {
  return String(s).replace(/"/g,"&quot;").replace(/'/g,"&#39;");
}
function formatDate(d) {
  return d.toLocaleDateString(undefined, { year:"numeric", month:"short", day:"numeric" });
}
function formatDateFull(d) {
  return d.toLocaleString(undefined, { year:"numeric", month:"short", day:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit" });
}

function showToast(msg, isError = false) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.style.borderColor = isError ? "var(--red)" : "var(--green)";
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2000);
}

// ── Init ─────────────────────────────────────────────────────────────────────
loadRecent();

// ── Drag & Drop ──────────────────────────────────────────────────────────────
const dropZone = document.getElementById("dropZone");

dropZone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropZone.classList.add("drag-over");
});

dropZone.addEventListener("dragleave", () => {
  dropZone.classList.remove("drag-over");
});

dropZone.addEventListener("drop", async (e) => {
  e.preventDefault();
  dropZone.classList.remove("drag-over");

  const url  = e.dataTransfer.getData("URL") || e.dataTransfer.getData("text/uri-list");
  const text = e.dataTransfer.getData("text/plain");
  const query = url || text;

  if (!query) {
    showToast("Не удалось получить данные закладки", true);
    return;
  }

  // Try exact URL search first, then text search
  let results = [];
  if (url) {
    results = await bmSearch({ url });
  }
  if (!results.length) {
    results = await bmSearch(query);
  }

  if (!results.length) {
    showToast("Закладка не найдена", true);
    return;
  }

  // Take first result, show props directly
  const bookmark = results[0];
  selectedBookmark = bookmark;
  loadAndShowProps(bookmark);
});
